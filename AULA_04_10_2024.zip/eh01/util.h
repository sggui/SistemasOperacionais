#ifndef __EH_BIBLIOTECA_H
#define __EH_BIBLIOTECA_H

void saudar(void);

#endif
