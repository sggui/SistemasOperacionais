#include <stdlib.h>

#include "util.h"

int main(){
	saudar();
	exit(EXIT_SUCCESS);
}

