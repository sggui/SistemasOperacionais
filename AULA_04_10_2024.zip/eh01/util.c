#include <stdio.h>

void saudar(void) {
	printf("Olá, mundo!");
}
